import Vue from 'vue'
import Router from 'vue-router'


Vue.use(Router)

export default new Router({
  scrollBehavior() {
    return { x: 0, y: 0 };
  },
  //mode: 'history',
  base: process.env.BASE_URL,
  routes: [
    { 
      path: '*', 
      component: () => import('./views/Notfound.vue')
    },
    {
      path: '/',
      name: 'Главная',
      meta: { layout: 'main' },
      component: () => import('./views/Home.vue')
    },
    {
      path: '/applications',
      name: 'Обращения',
      meta: {layout: 'main'},
      component: () => import('./views/Applications.vue')
    },
    {
      path: '/login',
      name: 'Авторизация',
      meta: { layout: 'empty' },
      component: () => import('./views/auth/Login.vue')
    },
    {
      path: '/users',
      name: 'Пользователи',
      meta: { layout: 'main' },
      component: () => import('./views/Users.vue')
    }
  ]
})
