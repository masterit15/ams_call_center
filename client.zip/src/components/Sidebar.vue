<template>
  <div>
    <v-navigation-drawer
      v-model="drawer"
      :color="color"
      :expand-on-hover="expandOnHover"
      :mini-variant="miniVariant"
      :right="right"
      :width="width"
      :fixed="fixed"
      absolute
      dark
    >
      <v-btn class="menu-open" icon @click="miniVariant = !miniVariant,sideOpen(miniVariant)" right>
        <v-icon>fa-outdent</v-icon>
      </v-btn>
      <v-list dense nav class="py-0">
        <v-list-item two-line>
          <!-- <v-list-item-avatar>
          <img src="https://randomuser.me/api/portraits/men/81.jpg" />
          </v-list-item-avatar>-->

          <v-list-item-content>
            <v-list-item-title>AMS</v-list-item-title>
            <v-list-item-subtitle>applications</v-list-item-subtitle>
          </v-list-item-content>
        </v-list-item>

        <v-divider></v-divider>

        <v-list-item v-for="item in items" :key="item.title" link>
          <router-link :to="item.href">
            <v-list-item-icon>
              <v-icon>{{ item.icon }}</v-icon>
            </v-list-item-icon>

            <v-list-item-content>
              <v-list-item-title>{{ item.title }}</v-list-item-title>
            </v-list-item-content>
          </router-link>
        </v-list-item>
      </v-list>
    </v-navigation-drawer>
  </div>
</template>

<script>
export default {
  data() {
    return {
      drawer: true,
      items: [
        { title: "Главная", icon: "fa-home", href: "/" },
        { title: "Обращения", icon: "fa-file", href: "/applications" },
        { title: "Архив", icon: "fa-archive", href: "/archive" },
        { title: "Статистика", icon: "fa-pie-chart", href: "/statistic" },
        { title: "Пользователи", icon: "fa-users", href: "/users" },
        { title: "Настройки", icon: "fa-cogs", href: "/options" }
      ],
      color: "primary",
      colors: ["primary", "blue", "success", "red", "teal"],
      right: false,
      width: 256,
      fixed: true,
      miniVariant: true,
      expandOnHover: true,
      background: false
    };
  },
  mounted() {
    this.saveOption();
  },
  methods: {
    saveOption() {
      let main = document.querySelector("body");
      if (this.getCookie("asideOpen") == "open") {
        main.classList.remove("close");
        main.classList.add("open");
        this.miniVariant = false;
        this.expandOnHover = false;
      } else {
        this.miniVariant = true;
        this.expandOnHover = true;
        main.classList.remove("open");
        main.classList.add("close");
      }
    },
    sideOpen(param) {
      this.expandOnHover = !this.expandOnHover;
      let main = document.querySelector("body");
      if (!param) {
        main.classList.remove("close");
        main.classList.add("open");
      } else {
        main.classList.remove("open");
        main.classList.add("close");
      }
      this.setCookie("asideOpen", main.classList.value);
    },
    setCookie(name, value, expires, path, domain, secure) {
      document.cookie =
        name +
        "=" +
        escape(value) +
        (expires ? "; expires=" + expires : "") +
        (path ? "; path=" + path : "") +
        (domain ? "; domain=" + domain : "") +
        (secure ? "; secure" : "");
    },
    getCookie(name) {
      let cookie = " " + document.cookie;
      let search = " " + name + "=";
      let setStr = null;
      let offset = 0;
      let end = 0;
      if (cookie.length > 0) {
        offset = cookie.indexOf(search);
        if (offset != -1) {
          offset += search.length;
          end = cookie.indexOf(";", offset);
          if (end == -1) {
            end = cookie.length;
          }
          setStr = unescape(cookie.substring(offset, end));
        }
      }
      return setStr;
    }
  }
};
</script>

  <style>
.v-list-item--link {
  /* text-align: center; */
  width: 100%;
  margin: 15px 0;
}
.v-list-item--link a {
  display: block;
  color: #fff !important;
  position: relative;
  float: left;
  text-align: center;
  width: 100%;
}
.open .v-list-item--link a .v-list-item__content {
  float: left;
  display: block;
}
.v-list-item__content,
.v-list-item__icon {
  float: none;
  margin: 0 15px;
}
.v-navigation-drawer:hover .v-list-item__content,
.v-list-item__icon {
  float: left;
}
.v-list-item--link a .v-list-item__content {
  display: none;
}
.v-navigation-drawer:hover a .v-list-item__content {
  display: block;
}
.v-navigation-drawer:hover .v-list-item--link {
  text-align: left;
}
.v-navigation-drawer--is-mouseover .v-btn--icon.v-size--default {
  float: right;
}
.menu-open {
  margin: 22px;
  display: block;
  transform: rotate(180deg);
  transition: all 0.3s ease;
}
.open .menu-open {
  float: right;
  background-color: rgb(59, 177, 167);
  transform: rotate(0deg);
  transition: all 0.3s ease;
}
.main-content {
  margin-left: 80px;
  transition: margin-left 0.3s ease;
}
.open .main-content {
  margin-left: 256px;
  transition: margin-left 0.3s ease;
}
</style>