<template>
<div>
  <nav class="nav">
            <div id="menu">
              <ul class="main-menu">
                <li>
                  <router-link to="/">Home</router-link>
                </li>
              </ul>
            </div>
          </nav>
</div>
</template>

<script>

export default {
  data() {
    return {
    };
  }
};
</script>
