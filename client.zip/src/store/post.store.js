import axios from "axios";
export default ({
  state: {
    posts: [],
    message: "",
    autor: [],
    poststatus: ["Все"],
    pagin: {},
    paginparams:{ page: 1, limit: 6 }
  },
  mutations: {
    SET_POSTS(state, posts) {
      state.posts = posts
    },
    SET_MESSAGE(state, message) {
      state.message = message
    },
    SET_STATUS(state, poststatus) {
      state.poststatus = poststatus
    },
    SET_PAGIN(state, pagin) {
      state.pagin = pagin
    },
  },
  actions: {
    addPost({commit, dispatch}, post) {
      console.log(post)
      axios.post('http://localhost:5000/api/posts/add', post)
        .then(response => {
          console.log(response)
          if (response.data.success) {
            dispatch('loadPost')
            message = "Обращение успешно добавлено"
            commit("SET_MESSAGE", message)
            commit("SET_POSTS", posts)
          }
        })
    },
    loadPost({ commit }, params) {
      let pagin = params.pagin
      axios.get("http://localhost:5000/api/posts/", {pagin}).then(response => {
          var poststatus = ["Все"]
        console.log(response)
          for (let i in response.data.posts.results){
            poststatus.push(response.data.posts.results[i].selectstatus)
          }
          commit("SET_STATUS", poststatus)
          let posts
        if (params.status != "Все") {
            posts = response.data.posts.results.find(post => post.selectstatus === status)
          }else{
            posts = response.data.posts.results
          }
          let pagin = response.data.posts.pagin
          commit("SET_POSTS", posts)
        commit("SET_PAGIN", pagin)
        });
    },
    editPost({commit, dispatch}, post) {
      if (confirm("Вы уверены что хотите редактировать обращение?")) {
        axios.put("http://localhost:5000/api/posts/", post).then(response => {
          if (response.data.success) {
            let message = response.data.message
            commit("SET_MESSAGE", message)
            dispatch('loadPost')
          } else {
            let message = response.data.message
            commit("SET_MESSAGE", message)
            dispatch('loadPost')
          }
        });
      }
    },
    deletePost({commit}, id, index) {
      if (confirm("Вы уверены что хотите удалить обращение?")) {
        axios.delete(`http://localhost:5000/api/posts/${id}`).then(response => {
          if (response.data.success) {
            let message = response.data.message
            commit("SET_MESSAGE", message)
          } else {
            let message = response.data.message
            commit("SET_MESSAGE", message)
          }
        });
      }
    },
  },
  getters: {
    posts(state){
      if (state.posts && state.posts.length > 1){
        return state.posts
      }else{
        return [state.posts]
      }
    },
    postsstatus(state){
      return state.poststatus
    },
    message(state) {
      return state.message
    },
    pagination(state) {
      return state.pagin
    }
  }
})