import axios from "axios";
export default ({
  state: {
    token: localStorage.getItem('access_token') || false,
    user: {},
    regmessage: '',
  },
  mutations: {
    SET_AUTH(state, authData){
      state.user = authData
    },
    SET_REGMESSAGE(state, message) {
      state.user = message
    },
  },
  actions: {
    auth({commit}, authData) {
      if (authData.saveswitch){
        localStorage.setItem('user_login', authData.email)
        localStorage.setItem('user_password', authData.password)
      }
      axios.post('http://localhost:5000/api/auth/login', authData)
        .then(response => {
          console.log(response)
          let token = response.data.token
          let userId = response.data.userId
          localStorage.setItem('access_token', token)
          localStorage.setItem('user_id', userId)
          let user = response.data
          commit("SET_AUTH", user)
        });
    },
    register({ commit }, authData){
        axios.post('http://localhost:5000/api/auth/register', authData)
          .then(response => {
            let regmessage = response.data.message
            commit("SET_REGMESSAGE", regmessage)
          });
    },
    logout(){
      localStorage.removeItem('access_token')
      localStorage.removeItem('user_id')
      localStorage.removeItem('user_login')
      localStorage.removeItem('user_password')
      let logIn = false
    }
  },
  getters: {
    login(state){
      return state.token
    },
    regMessage(state){
      return state.regmessage
    },
  }
})