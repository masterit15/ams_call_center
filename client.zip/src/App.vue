<template>
  <div id="app">
    <v-app>
      <component :is="layout">
        <router-view></router-view>
      </component>
      <div class="logout" v-show="login">
      <v-btn fab dark color="cyan" @click="logout(), ifAuth = false">
        <v-icon dark>fa-sign-out</v-icon>
      </v-btn>
    </div>
    </v-app>
  </div>
</template>

<script>
import EmptyLayout from '~/layouts/Emptylayout.vue'
import MainLayout from '~/layouts/Mainlayout.vue'
import {mapActions, mapGetters} from 'vuex'
export default {
  data() {
    return {
      ifAuth: localStorage.getItem('access_token') || false
    }
  },
  computed: {
    ...mapGetters(['login']),
    layout(){
      return (this.$route.meta.layout || 'empty') + '-layout'
    }
  },
  methods: {
    ...mapActions(['logout'])
  },
  components: {
    EmptyLayout, MainLayout
  }
};
</script>
<style >
.logout {
  position: fixed;
  left: 10px;
  bottom: 20px;
  z-index: 20;
}
.main-content {
  position: relative;
}
.slide-fade-enter-active {
  transition: all 0.2s cubic-bezier(1, 0.5, 0.8, 1);
}
.slide-fade-enter,
.slide-fade-leave-to {
  transform: translateY(50px);
  opacity: 0;
}
</style>