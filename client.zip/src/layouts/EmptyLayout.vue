<template>
          <transition name="slide-fade">
            <router-view />
          </transition>
</template>