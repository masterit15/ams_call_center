<template>
  <v-container>
    <v-row>
      <v-col col="12" sm="6">
        <v-card>
          <v-sheet
            class="v-sheet--offset mx-auto theme--dark"
            color="cyan"
            :height="100"
            elevation="12"
            max-width="calc(100% - 32px)"
          >
            <v-divider class="my-2"></v-divider>
            <h2 class="text-center font-weight-bold">Добавить пользователя</h2>
          </v-sheet>
          <v-form v-model="valid" @submit="register(authData)">
            <v-container>
              <v-row>
                <v-col cols="12">
                  <ValidationProvider name="Email" rules="required|email" v-slot="{ errors, valid }">
                  <v-text-field
                    v-model="authData.email"
                    :error-messages="errors"
                    :success="valid"
                    label="E-mail"
                    required
                  ></v-text-field>
                  </ValidationProvider>
                </v-col>
                <v-col cols="12">
                  <ValidationProvider name="Name" rules="required" v-slot="{ errors, valid }">
                    <v-text-field
                      v-model="authData.userName"
                      :error-messages="errors"
                      :success="valid"
                      label="ФИО"
                      required
                    ></v-text-field>
                  </ValidationProvider>
                </v-col>
                <v-col cols="12">
                  <ValidationObserver>
                    <ValidationProvider name="confirm" rules="required|min:8" v-slot="{ errors }">
                      <v-text-field
                        v-model="confirmation"
                        :append-icon="showpassw ? 'fa-eye' : 'fa-eye-slash'"
                        :type="showpassw ? 'text' : 'password'"
                        :error-messages="errors"
                        label="Повторите пароль"
                        counter
                        hint="Не менее 8 символов"
                        @click:append="showpassw = !showpassw"
                      ></v-text-field>
                    </ValidationProvider>
                    <ValidationProvider rules="required|password:@confirm" v-slot="{ errors }">
                      <v-text-field
                        v-model="authData.password"
                        :append-icon="showpassw ? 'fa-eye' : 'fa-eye-slash'"
                        :type="showpassw ? 'text' : 'password'"
                        :error-messages="errors"
                        label="Пароль"
                        hint="Не менее 8 символов"
                        counter
                        @click:append="showpassw = !showpassw"
                      ></v-text-field>
                    </ValidationProvider>
                  </ValidationObserver>
                </v-col>
              </v-row>
            </v-container>
            <div class="text-center">
              <v-btn type="submit" color="green" class="ma-2 white--text">
                Добавить
                <v-icon right small dark>fa-user-plus</v-icon>
              </v-btn>
            </div>
          </v-form>
        </v-card>
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
import { mapActions, mapGetters } from "vuex";
import axios from "axios";
export default {
  data: () => ({
    pass: "",
    pass2: "",
    showpassw: false,
    valid: false,
    fio: "",
    authData: {
      saveswitch: false,
      email: "",
      userName: "",
      password: ""
    },
    confirmation: "",
  }),
  watch: {
    getAuth() {
      if (this.getAuth) {
        this.$router.push("/");
      }
    }
  },
  mounted() {},
  computed: {
    ...mapGetters(["getAuth"])
  },
  methods: {
    ...mapActions(["register"])
  }
};
</script>