// Router Initialization
const express = require('express');
const router = express.Router();

// Bring in Post Schema
const Post = require('../models/Post');

/*
    GET Method Route to get all the posts
*/
router.get('/', paginatedResults(Post), (req, res) => {
    
    console.log(req.query)
    return res.json({
        success: true,
        posts: res.paginatedResults
    });
});

/* 
    POST Method to Add a Post 
*/
router.post('/add', (req, res, next) => {

    let fio             = req.body.fio
    let text            = req.body.text
    let selectstatus    = req.body.selectstatus
    let address         = req.body.address
    let creDate         = req.body.creDate
    let conDate         = req.body.conDate
    let regNumber       = req.body.regNumber
    let phoneNumber     = req.body.phoneNumber
    let owner           = req.body.owner

    // Validation
    if (fio === undefined || text === undefined || address === undefined) {
        return res.json({
            success: false,
            message: 'Please fill in all fields'
        });
    } else {
        // Create a new Post Instance
        let newPost = new Post({
            fio,   
            text,
            selectstatus,
            address,
            creDate,
            conDate,
            regNumber,
            phoneNumber,
            owner
        });
        // Save the created Instance
        newPost.save().then((post) => {
            return res.json({
                success: true,
                post,
                message: 'Post added to database successfully.'
            });
        }).catch((err) => {
            return res.json({
                success: false,
                message: 'Unable to save the Post.',
                err: err
            });
        });
    }
});

/*
    GET Method single post by Id
*/
router.get('/:id', (req, res, next) => {
    let id = req.params.id;
    Post.findOne({
        _id: id
    }).then((post) => {
        return res.json({
            success: true,
            post: post
        });
    }).catch((err) => {
        return res.json({
            success: false,
            message: 'Unable to get the Post.',
            err: err
        });
    });
});

/*
    PUT Method to Update single Post by Id
*/

router.put('/', (req, res, next) => {

    let fio = req.body.fio
    let text = req.body.text
    let selectstatus = req.body.selectstatus
    let address = req.body.address
    let creDate = req.body.creDate
    let conDate = req.body.conDate
    let regNumber = req.body.regNumber
    let phoneNumber = req.body.phoneNumber
    let owner = req.body.owner

    let id = req.body._id;

    

    Post.findOne({
        _id: id
    }).then((post) => {
        post.fio = fio
        post.text = text
        post.selectstatus = selectstatus
        post.address = address
        post.creDate = creDate
        post.conDate = conDate
        post.regNumber = regNumber
        post.phoneNumber = phoneNumber
        post.owner = owner
        post.save()
            .then((post) => {
                return res.json({
                    success: true,
                    message: 'Обращение успешно обновлено',
                    post: post
                });
            }).catch((err) => {
                return res.json({
                    success: false,
                    message: 'Не удается обновить обращение',
                    err: err
                });
            });
    }).catch((err) => {
        return res.json({
            success: false,
            message: 'Ошибка! что-то пошло не так.',
            err: err
        });
    });
});

router.delete('/:id', (req, res, next) => {
    let id = req.params.id;
    Post.findOneAndDelete({
        _id: id
    }).then((post) => {
        return res.json({
            success: true,
            message: 'Post deleted successfully',
            post: post
        });
    }).catch((err) => {
        return res.json({
            success: false,
            message: 'Unable to delete the Post',
            err: err
        });
    });
})
function paginatedResults(model) {
    return async (req, res, next) => {
        const page = parseInt(req.query.page)
        const limit = parseInt(req.query.limit)
        
        const startIndex = (page - 1) * limit
        const endIndex = page * limit

        const results = {}

        const total = await model.countDocuments().exec()
        results.pagin = {
            currentPage: page,
            total: total,
            limit: limit,
            pageCount: Math.ceil(total / limit)
        }
        if (endIndex < await model.countDocuments().exec()) {
            results.next = {
                page: page + 1,
            }
        }

        if (startIndex > 0) {
            results.previous = {
                page: page - 1,
            }
        }
        try {
            results.results = await model.find().limit(limit).skip(startIndex).exec()
            res.paginatedResults = results
            next()
        } catch (e) {
            res.status(500).json({ message: e.message })
        }
    }
}

module.exports = router;