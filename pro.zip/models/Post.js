const { Schema, model, Types } = require('mongoose')
const schema = new Schema({
  // _id: { type: Number },
  fio: { type: String, required: true },
  text: { type: String },
  selectstatus: { type: String },
  regNumber: { type: Number},
  address: { type: String, default: "Не обработана" },
  creDate: { type: Date, default: Date.now},
  conDate: { type: Date },
  phoneNumber: { type: String, pattern: "^([0-9]{3}-[0-9]{3}-[0-9]{4}$"},
  owner: { type: Types.ObjectId, ref: 'User' }
})


module.exports = model('Post', schema)