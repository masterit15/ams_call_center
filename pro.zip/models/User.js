const {Schema, model, Types} = require('mongoose')
const schema = new Schema({
    email: { type: String, required: true, unique: true },
    permission: { type: String, default: 'employee'},
    userName: { type: String },
    password: { type: String, required: true },
    post: [{ type: Types.ObjectId, ref: 'Post' }]
})

module.exports = model('User', schema)